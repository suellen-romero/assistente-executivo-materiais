# /decisao — Registrar decisão

O CEO tomou ou quer registrar uma decisão. Documente em memoria/decisoes.md.

## Processo

1. Se o CEO não detalhou, pergunte:
   - O que foi decidido?
   - Por quê? (contexto)
   - Tem prazo?
   - Alguém precisa ser comunicado?
   - É permanente ou pode mudar?

2. Registre em memoria/decisoes.md no formato:

```
### [DATA] - [TÍTULO DA DECISÃO]
- **Decisão:** [o que foi decidido]
- **Contexto:** [por que]
- **Impacto:** [o que muda]
- **Expectativa de resultado:** [o que espera que aconteça com essa decisão]
- **Estimativa de custo:** [quanto vai custar, se aplicável]
- **Envolvidos:** [quem precisa executar ou ser comunicado]
- **Prazo:** [se houver]
- **Status:** Ativa | Permanente
```

3. Confirme: "Registrado em decisoes.md: [título da decisão]"

## Importante
- Se a nova decisão contradiz uma anterior, alertar: "Isso contradiz a decisão de [data] sobre [tema]. Registro a nova e marco a anterior como substituída?"
- Decisões marcadas como "Permanente" nunca são movidas na manutenção

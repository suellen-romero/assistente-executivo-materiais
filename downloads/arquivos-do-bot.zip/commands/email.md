# /email — Rascunhar email

Rascunhe um email com base no que o CEO pedir. Adapte tom e extensão ao contexto.

## Processo

1. Entenda: pra quem, sobre o quê, qual tom (se não especificar, pergunte)
2. Consulte memoria/aprendizados.md pra verificar preferências de tom e formato
3. Consulte memoria/preferencias.md pra verificar se há contexto sobre o destinatário
4. Rascunhe o email

## Regras

- Máximo 3-4 parágrafos (a menos que o CEO peça diferente)
- Sempre incluir assunto sugerido
- Tom padrão: profissional, direto, sem enrolação
- Se for email delicado (demissão, reclamação, investidor): oferecer 2 versões (mais firme / mais diplomático)

## Formato de saída

```
📧 EMAIL

Para: [destinatário]
Assunto: [assunto sugerido]

---

[corpo do email]

---
```

## Após rascunhar
Pergunte: "Quer ajustar algo ou posso enviar?" (se Gmail/Outlook conectado)
Se o CEO aprovar E houver decisão sobre aprovação em memoria/decisoes.md (ex: "emails pra investidor passam por revisão do sócio"), alertar antes de enviar.

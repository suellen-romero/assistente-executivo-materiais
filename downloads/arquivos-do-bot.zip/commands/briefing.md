# /briefing — Briefing matinal

Gere o briefing do dia para o CEO. Siga esta estrutura:

## 1. Emails prioritários
- Acesse o email (Gmail/Outlook) e liste os 5 mais importantes
- Classifique por urgência: URGENTE / IMPORTANTE / INFORMATIVO
- Para cada um: remetente, assunto, resumo em 1 linha, ação sugerida

## 2. Agenda do dia
- Acesse o calendário e liste todos os compromissos de hoje
- Para cada reunião: horário, com quem, contexto (consulte memoria/ se houver histórico)
- Destaque se alguma reunião precisa de preparação

## 3. Pendências
- Leia memoria/pendencias.md
- Liste pendências com prazo pra hoje ou atrasadas
- Destaque as 3 mais urgentes

## 4. Contexto
- Leia memoria/contexto-semanal.md
- Mencione qualquer alerta ou prioridade da semana

## Formato de saída
Conciso. Máximo 1 tela de Telegram. Use este formato:

```
📧 EMAILS (X novos)
🔴 [remetente] — [assunto] → [ação]
🟡 [remetente] — [assunto] → [ação]

📅 AGENDA
[horário] — [reunião] com [pessoa]
[horário] — [reunião] com [pessoa]

⚡ PENDÊNCIAS (X abertas, Y atrasadas)
🔴 [pendência atrasada]
🟡 [pendência pra hoje]

💡 CONTEXTO
[o que está acontecendo esta semana]
```

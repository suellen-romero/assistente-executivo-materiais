# /pendencias — Listar pendências

Mostre todas as pendências abertas organizadas por urgência.

## Processo

1. Leia memoria/pendencias.md
2. Classifique por prazo
3. Apresente organizado

## Formato de saída

```
📋 PENDÊNCIAS

🔴 ATRASADAS ([N])
- [ ] [descrição] | Prazo: [data] | Responsável: [quem] — [X dias de atraso]
  ⚠️ Impacto do atraso: [o que acontece se continuar atrasado]

🟡 ESTA SEMANA ([N])
- [ ] [descrição] | Prazo: [data] | Responsável: [quem]

🔵 PRÓXIMAS SEMANAS ([N])
- [ ] [descrição] | Prazo: [data] | Responsável: [quem]

⚪ SEM PRAZO ([N])
- [ ] [descrição] | Responsável: [quem]

Total: [N] abertas | [N] atrasadas
```

## Ações
Após listar, pergunte: "Quer marcar alguma como concluída, mudar prazo, ou adicionar nova?"

Se o CEO disser que algo foi concluído, marcar com [x] e adicionar data de conclusão.

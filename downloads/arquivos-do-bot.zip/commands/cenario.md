# /cenario — Modelar cenário

O CEO quer entender o impacto de uma decisão. Modele cenários base, otimista e pessimista.

## Processo

1. Entenda a decisão (ex: "contratar 3 pessoas", "mudar de fornecedor", "lançar produto novo")
2. Peça os dados que faltam (valores, prazos, premissas)
3. Se houver dados financeiros em camada2-empresa/ ou memoria/, use como base
4. Modele 3 cenários

## Formato de saída

```
📊 MODELAGEM DE CENÁRIO

DECISÃO: [o que está sendo avaliado]
PREMISSAS: [dados usados como base]

🟢 CENÁRIO OTIMISTA
[descrição + números]
Resultado: [impacto financeiro/operacional]

🟡 CENÁRIO BASE (mais provável)
[descrição + números]
Resultado: [impacto financeiro/operacional]

🔴 CENÁRIO PESSIMISTA
[descrição + números]
Resultado: [impacto financeiro/operacional]

📋 VARIÁVEIS-CHAVE
- [o que mais afeta o resultado]
- [o que pode dar errado]

💬 RECOMENDAÇÃO
[o que faria baseado nos dados + o que monitorar]
```

## Importante
- Use números concretos, não percentuais vagos
- Se faltar dados, pergunte antes de chutar
- Consulte memoria/decisoes.md pra não contradizer decisão anterior

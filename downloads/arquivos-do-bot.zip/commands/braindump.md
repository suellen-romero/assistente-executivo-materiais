# /braindump — Organizar brain dump

O CEO vai despejar tudo que está na cabeça (texto ou áudio). Organize o conteúdo.

## Processo

1. Se receber áudio: transcrever com Whisper primeiro
2. Ler todo o conteúdo sem interromper
3. Organizar por tema automaticamente

## Formato de saída

```
🧠 BRAIN DUMP ORGANIZADO

📋 TAREFAS (coisas pra fazer)
- [ ] [tarefa] → sugestão de prazo
- [ ] [tarefa] → sugestão de prazo

💡 IDEIAS (coisas pra pensar depois)
- [ideia 1]
- [ideia 2]

📞 PESSOAS (coisas que envolvem alguém)
- [nome]: [o que precisa fazer/falar com essa pessoa]

⚡ URGENTE (precisa de ação hoje)
- [item urgente]

📝 REFERÊNCIA (informação pra guardar)
- [dado/info relevante]
```

## Após organizar
1. Pergunte: "Quer que eu registre as tarefas em pendencias.md?"
2. Se sim, registre cada tarefa com prazo sugerido
3. Se alguma ideia parece uma decisão, pergunte: "Isso é uma decisão tomada ou ainda está pensando?"
4. Registre ideias relevantes em memoria/contexto-semanal.md

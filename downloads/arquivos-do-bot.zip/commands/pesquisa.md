# /pesquisa — Pesquisar e comparar

Pesquise na web e apresente opções comparadas para o que o CEO pedir: fornecedores, restaurantes, hotéis, serviços, ferramentas, etc.

## Processo

1. Entenda o que buscar e os critérios (preço, localização, avaliação, etc)
2. Consulte memoria/preferencias.md pra verificar preferências existentes
3. Pesquise na web
4. Apresente top 3-5 opções comparadas

## Formato de saída

```
🔍 PESQUISA: [o que foi pesquisado]

CRITÉRIOS: [o que foi considerado]

1️⃣ [OPÇÃO 1]
   [detalhes relevantes]
   Preço: [valor]
   Prazo de entrega: [prazo]
   Frete: [incluso/valor/condição]
   Pagamento: [opções disponíveis]
   Validade da proposta: [se houver]
   Avaliação: [nota/reviews]
   Link: [URL]

2️⃣ [OPÇÃO 2]
   [detalhes]
   Preço: [valor]
   Prazo de entrega: [prazo]
   Frete: [incluso/valor/condição]
   Pagamento: [opções]
   Validade: [se houver]
   Avaliação: [nota]
   Link: [URL]

3️⃣ [OPÇÃO 3]
   [detalhes]
   Preço: [valor]
   Prazo de entrega: [prazo]
   Frete: [incluso/valor/condição]
   Pagamento: [opções]
   Validade: [se houver]
   Avaliação: [nota]
   Link: [URL]

💬 RECOMENDAÇÃO
[qual escolheria e por quê]
```

## Após apresentar
Pergunte: "Quer que eu registre [opção escolhida] em preferencias.md pra próxima vez?"

# /analise — Analisar documento

Analise o documento que o CEO enviar (PDF, planilha, imagem, texto). Adapte o formato conforme o tipo.

## Identificar o tipo

- **Contrato**: foco em riscos, cláusulas desfavoráveis, prazos, multas
- **Proposta comercial**: foco em preço, condições, comparação com mercado
- **Relatório financeiro**: foco em tendências, anomalias, pontos de atenção
- **Currículo**: foco em fit com a vaga, pontos fortes, red flags
- **Genérico**: resumo executivo + pontos principais

## Formato por tipo

### Contrato
```
📄 ANÁLISE DE CONTRATO

PARTES: [quem são]
OBJETO: [o que trata]
VALOR: [valor e condições]
PRAZO: [duração e renovação]

⚠️ RISCOS
1. [cláusula X] — [por que é risco] — [sugestão]
2. [cláusula Y] — [por que é risco] — [sugestão]

✅ PONTOS FAVORÁVEIS
- [ponto positivo]

💬 RECOMENDAÇÃO
[aceitar/negociar/rejeitar + justificativa]
```

### Proposta comercial
```
📄 ANÁLISE DE PROPOSTA

DE: [empresa]
VALOR: [preço]
CONDIÇÕES: [prazo, pagamento, garantia]

SOBRE O FORNECEDOR
[Resumo de até 10 linhas sobre a empresa, o que fazem, tamanho,
tempo de mercado, cargo do contato, contexto]

🔍 REPUTAÇÃO
- Reclame Aqui: [nota, volume de reclamações, taxa de resposta]
- Google Meu Negócio: [nota, número de avaliações]
- Outros: [referências encontradas na web]

COMPARAÇÃO
[comparar com o que paga hoje se houver referência em memoria/]

💡 ARGUMENTOS DE NEGOCIAÇÃO
1. [argumento pra reduzir valor ou melhorar condição]
2. [argumento baseado em mercado ou concorrência]
3. [argumento baseado em volume, prazo ou relacionamento]

💬 RECOMENDAÇÃO
[aceitar/negociar/buscar alternativa + justificativa]
```

### Relatório financeiro
```
📊 ANÁLISE FINANCEIRA

PERÍODO: [qual]
RESUMO: [2-3 linhas]

ANÁLISE
[Até 10 linhas: tendências identificadas, comparação com períodos
anteriores, anomalias, correlações entre métricas, contexto de
mercado que pode estar influenciando os números, riscos e
oportunidades que os dados revelam]

📈 DESTAQUES POSITIVOS
- [métrica que melhorou + por quê]

📉 PONTOS DE ATENÇÃO
- [métrica preocupante + impacto se não agir]

❓ PERGUNTAS PARA O CFO
- [pergunta 1]
- [pergunta 2]
```

## Após analisar
Pergunte: "Quer que eu salve em anexos/ pra consulta futura?"

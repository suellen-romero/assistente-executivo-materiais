# /registra — Forçar registro na memória

O CEO quer registrar algo na memória que o assistente não registrou automaticamente.

## Processo

1. Leia o que o CEO mandou
2. Classifique automaticamente:
   - É uma **decisão**? → memoria/decisoes.md
   - É uma **pendência/tarefa**? → memoria/pendencias.md
   - É uma **preferência pessoal**? (gosto, fornecedor favorito, contato) → memoria/preferencias.md
   - É uma **correção/aprendizado**? (como o CEO quer as coisas) → memoria/aprendizados.md
   - É **contexto atual**? (algo que está acontecendo) → memoria/contexto-semanal.md
   - Não se encaixa? Pergunte onde salvar.

3. Registre no arquivo correto com o formato padrão de cada arquivo

4. Confirme: "Registrado em [arquivo]: [resumo do que foi salvo]"

## Exemplos

CEO manda: "meu restaurante favorito pra negócios é o Sushi Isao em Campinas"
→ Salvar em memoria/preferencias.md na seção Alimentação

CEO manda: "nunca mais me mande email com mais de 4 parágrafos"
→ Salvar em memoria/aprendizados.md na seção Comunicação

CEO manda: "a gente vai lançar o produto novo em setembro"
→ Salvar em memoria/contexto-semanal.md na seção Projetos

CEO manda: "decidi não renovar o contrato com a agência"
→ Salvar em memoria/decisoes.md com formato completo

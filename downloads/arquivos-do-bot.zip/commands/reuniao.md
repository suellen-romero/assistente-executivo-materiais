# /reuniao — Preparar reunião

Prepare um briefing completo para a próxima reunião. Pergunte com quem é a reunião se não foi especificado.

## 1. Pesquisa
- Se for com empresa externa: pesquise na web (site, LinkedIn, notícias recentes, últimas movimentações)
- Se for com pessoa do time: consulte camada2-empresa/time.md
- Busque informações atualizadas sobre a pessoa/empresa pra encontrar um gancho de conversa

## 2. Histórico
- Busque em memoria/decisoes.md decisões anteriores envolvendo essa pessoa/empresa
- Busque em sessoes/ menções recentes
- Busque emails recentes trocados com essa pessoa (se Gmail/Outlook conectado)
- Busque em memoria/pendencias.md compromissos pendentes com essa pessoa/empresa

## 3. Briefing

Gere o briefing neste formato:

```
🤝 REUNIÃO: [pessoa/empresa]
📅 [data e horário]

SOBRE
[Resumo de até 10 linhas sobre a pessoa/empresa, cargo, contexto,
o que fazem, tamanho, mercado, momento atual]

🎯 GANCHO
[Assunto atualizado pra abrir a conversa: notícia recente sobre a
pessoa/empresa, algo em comum, conquista recente, mudança no mercado.
Precisa ser algo novo e relevante, não genérico.]

HISTÓRICO CONOSCO
[Últimas interações, decisões pendentes, compromissos, emails trocados,
últimas conversas, menções em sessões, qualquer contexto anterior]

PAUTA SUGERIDA
1. [tópico]
2. [tópico]
3. [tópico]

PERGUNTAS ESTRATÉGICAS
- [pergunta 1]
- [pergunta 2]
- [pergunta 3]

⚠️ PONTOS DE ATENÇÃO
[qualquer coisa que precisa saber antes de entrar]

📎 EXTRAS
[Informações adicionais que podem contribuir com a reunião:
dados de mercado, comparativos, referências, materiais relevantes]
```

## 4. Após a reunião
Pergunte: "Como foi a reunião? Quer que eu registre decisões ou pendências? Algum ajuste no modelo de preparação de reunião pra próxima vez?"

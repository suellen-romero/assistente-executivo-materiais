# /feedback — Montar feedback estruturado

Monte um feedback usando o framework SBI (Situação, Comportamento, Impacto). Pergunte pra quem e sobre o quê.

## Processo

1. Pergunte (se não especificou):
   - Pra quem é o feedback?
   - É construtivo (corrigir algo) ou reconhecimento (elogiar)?
   - O que aconteceu? (a situação)
2. Consulte camada2-empresa/time.md pra contexto sobre a pessoa
3. Consulte memoria/aprendizados.md pra tom preferido do CEO
4. Monte o feedback

## Formato — Construtivo

```
💬 FEEDBACK PARA: [nome]
Tipo: Construtivo

SITUAÇÃO
[Quando e onde aconteceu — fato, não opinião]

COMPORTAMENTO
[O que a pessoa fez — ação específica observável]

IMPACTO
[Qual foi o efeito no time, no projeto, no resultado]

EXPECTATIVA
[O que espero que mude — pedido claro e específico]

APOIO
[Como posso ajudar a pessoa a melhorar]
```

## Formato — Reconhecimento

```
💬 FEEDBACK PARA: [nome]
Tipo: Reconhecimento

SITUAÇÃO
[Quando e onde aconteceu]

COMPORTAMENTO
[O que a pessoa fez de excepcional]

IMPACTO
[Que diferença isso fez]

RECONHECIMENTO
[Agradecimento e incentivo a continuar]
```

## Após montar
Pergunte: "Quer enviar como mensagem, como email, ou prefere falar pessoalmente?"

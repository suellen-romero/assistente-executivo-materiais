# /ata — Registrar ata de reunião

Registre a ata de uma reunião. O CEO pode mandar por texto ou áudio.

## Processo

1. Se receber áudio: transcrever com Whisper primeiro
2. Se o CEO mandou notas soltas: organizar no formato abaixo
3. Se quer que acompanhe em tempo real: pedir que mande mensagens durante a reunião e consolidar no final

## Formato de saída

```
📝 ATA DE REUNIÃO

Data: [data]
Participantes: [quem estava]
Assunto: [tema principal]

CONTEXTO
[por que essa reunião aconteceu — 1-2 linhas]

DISCUSSÃO
[pontos principais discutidos — resumido, não transcrição]

DECISÕES TOMADAS
1. [decisão] — Responsável: [quem]
2. [decisão] — Responsável: [quem]

AÇÕES / PRÓXIMOS PASSOS
- [ ] [ação] | Responsável: [quem] | Prazo: [data]
- [ ] [ação] | Responsável: [quem] | Prazo: [data]

PENDÊNCIAS ANTERIORES DISCUTIDAS
- [pendência X]: [status atualizado]
```

## Após registrar
1. Pergunte: "Quer que eu registre as decisões em decisoes.md e as ações em pendencias.md?"
2. Se sim, registrar automaticamente
3. Pergunte: "Quer que eu envie a ata por email pros participantes?"

# CASOS DE USO — COMUNICAÇÃO

> 8 cenários para emails, mensagens, feedbacks e comunicados.

---

### 26. Email difícil pra fornecedor

**Situação:** Fornecedor aumentou preço 40%. Precisa ser firme mas profissional.

**O que mandar:**
```
/email pro João da ABC, sobre o reajuste de 40%. Tom firme.
Dizer que é inaceitável e que vou buscar alternativas.
```

**O que o assistente faz:** Consulta aprendizados.md pro tom preferido. Rascunha 2 versões (firme e diplomática).

**Dica:** Se corrigir o tom, o assistente aprende e acerta da próxima vez.

---

### 27. Emails em lote

**Situação:** 5 emails esperando resposta. Não quer abrir um por um.

**O que mandar:**
```
Responde esses 5 emails:
1. João: confirma reunião terça 14h
2. Maria: aprovado, pode seguir
3. Contador: pede pro Alexandre enviar
4. Cliente Y: agradecer, retorno segunda
5. Newsletter: desinscrever
```

**O que o assistente faz:** Rascunha todos e apresenta pra aprovação em lote.

**Dica:** Faça no final do dia pra zerar a caixa em 2 minutos.

---

### 28. Comunicado interno pro time

**Situação:** Mudança de política. Precisa comunicar sem gerar p✓nico.

**O que mandar:**
```
Rascunha comunicado: home office muda de 3 pra 2 dias.
Tom transparente mas positivo.
```

**O que o assistente faz:** Rascunha com motivos, data de início e abertura pra dúvidas.

**Variações:**
- Meta não atingida — tom de responsabilidade
- Nova contratação — celebração
- Demissão — tom respeitoso e breve

---

### 29. Feedback construtivo usando SBI

**Situação:** Alguém do time entregou abaixo. Precisa falar.

**O que mandar:**
```
/feedback construtivo pro Lucas. Atrasou 3 entregas e o cliente reclamou.
```

**O que o assistente faz:** Monta no framework SBI (Situação, Comportamento, Impacto) + Expectativa + Apoio.

**Dica:** Registre "dei feedback pro Lucas" pra manter histórico.

---

### 30. Cobrança educada

**Situação:** Pediu algo 3 vezes e ninguém fez.

**O que mandar:**
```
Cobra o Thamer do relatório. Já pedi 2 vezes. Sem ser grosso mas urgente.
```

**O que o assistente faz:** Mensagem direta, respeitosa, com prazo claro.

**Dica:** Se virar padrão com a mesma pessoa, o assistente nota e te alerta.

---

### 31. Responder cliente insatisfeito

**Situação:** Cliente reclamou por email. Precisa responder rápido.

**O que mandar:**
```
Responde pro Carlos. Reclama do downtime. Assume erro, oferece crédito.
```

**O que o assistente faz:** Analisa histórico do cliente, rascunha resposta empática com plano de ação.

**Variações:**
- Tom formal pra enterprise
- Sem desconto, só plano de ação
- Inclui detalhes técnicos

---

### 32. Mensagem de agradecimento personalizada

**Situação:** Alguém te ajudou. Quer agradecer com subst✓ncia.

**O que mandar:**
```
Agradece o Marcos. Indicou 3 clientes, todos fecharam.
```

**O que o assistente faz:** Mensagem genuína, específica, sem genérico.

**Dica:** O assistente pode lembrar datas importantes dessas pessoas.

---

### 33. Post pro LinkedIn

**Situação:** Quer postar mas não tem tempo de escrever.

**O que mandar:**
```
Post sobre retenção vs aquisição. Tom pessoal, da minha experiência. 200 palavras.
```

**O que o assistente faz:** Consulta minha-metodologia.md pro tom. Gancho forte, experiência, CTA sutil.

**Variações:**
- Lição da semana
- Celebrar resultado
- Erro que cometeu

**Dica:** Diga o tom (inspirador, técnico, vulnerável) e o assistente adapta.

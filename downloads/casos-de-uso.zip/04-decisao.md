# CASOS DE USO — DECISÃO

> 5 cenários para modelar cenários, avaliar trade-offs e registrar decisões.

---

### 21. Modelar impacto de uma contratação

**Situação:** Pensando em contratar 3 pessoas. Quer entender o impacto financeiro.

**O que mandar:**
```
/cenario se eu contratar 3 vendedores a R$6k cada,
com meta de R$50k/mês por vendedor após ramp-up de 3 meses
```

**Output esperado:**
```
📋 MODELAGEM DE CENÁRIO

DECISÃO: Contratar 3 vendedores
PREMISSAS: Salário R$6k + encargos (~80%) = R$10.8k/pessoa/mês.
Ramp-up: 3 meses. Meta: R$50k/mês por vendedor após ramp.

📢 OTIMISTA
3 vendedores atingem meta no mês 3.
Investimento: R$97k (3 meses à 3 pessoas à R$10.8k)
Retorno: R$150k/mês a partir do mês 4
Payback: mês 5
ROI ano 1: 4.6x

🟡 BASE
2 de 3 atingem meta. 1 demora 5 meses.
Investimento: R$97k
Retorno: R$115k/mês a partir do mês 4
Payback: mês 6
ROI ano 1: 3.1x

🔴 PESSIMISTA
1 não funciona (demite no mês 4). 2 atingem 70% da meta.
Investimento: R$140k (inclui rescisão)
Retorno: R$70k/mês
Payback: mês 9
ROI ano 1: 1.2x

📋 VARIÁVEIS-CHAVE
- Taxa de sucesso na contratação (seu histórico: ?)
- Ramp-up real vs estimado
- Pipeline atual suporta 3 vendedores extras?

💬 RECOMENDAÇÃO
Contratar 2 primeiro, validar o ramp-up, depois o 3º.
Reduz o risco do cenário pessimista pela metade.
```

**Variações:**
- "E se eu contratar sênior a R$12k em vez de júnior?"
- "Inclui comissão de 5% na modelagem"
- "Compara contratar vs terceirizar"

**Dica:** Registre a decisão com /decisao depois de decidir. O assistente guarda as premissas.

---

### 22. Avaliar se deve aceitar ou recusar uma oportunidade

**Situação:** Alguém te ofereceu parceria mas você não tem certeza se vale a pena.

**O que mandar:**
```
Me ajuda a pensar: a TechFlow quer parceria de integração.
Eles pagam 20% de comissão por indicação mútua.
Vale a pena? O que preciso considerar?
```

**Output esperado:**
```
📋 AVALIAÇÃO DE OPORTUNIDADE

PROPOSTA: Parceria de indicação mútua com TechFlow (20% comissão)

A FAVOR
- Canal de aquisição novo sem custo fixo
- TechFlow tem 300+ clientes no seu ICP
- 20% de comissão é acima do mercado (padrão: 10-15%)
- Sinergia de produto (vocês resolvem problemas complementares)

CONTRA
- Integração técnica: quanto tempo e custo de desenvolvimento?
- Risco de reputação: se o produto deles falhar, reflete em você
- Esforço operacional: quem gerencia as indicações?
- Exclusividade: eles pedem exclusividade no segmento?

PERGUNTAS QUE FALTAM
1. A comissão é recorrente ou só no primeiro mês?
2. Tem mínimo de indicações? Penalidade se não atingir?
3. Quanto tempo pra integrar?
4. Posso falar com 2-3 parceiros atuais deles?

CENÁRIOS
- Se cada parceiro indicar 5 clientes/mês a R$3k ticket:
  Receita de comissão: R$3k/mês (36k/ano)
- Se indicar 15/mês (otimista): R$9k/mês (108k/ano)

💬 RECOMENDAÇÃO
Vale explorar mas não fechar agora. Pedir: contrato sem
exclusividade, teste de 3 meses, e falar com parceiros atuais.
```

**Dica:** Peça "rascunha email pro Rafael aceitando com condições" e o assistente já monta.

---

### 23. Decidir entre duas opções quando está em dúvida

**Situação:** Duas opções, não sabe qual escolher. Precisa de um framework.

**O que mandar:**
```
/cenario
Estou entre renovar o contrato com o fornecedor atual (R$6.200/mês)
ou trocar pro novo (R$7.800/mês mas com mais features).
Me ajuda a pensar.
```

**Output esperado:**
```
📋 ANÁLISE DE TRADE-OFF

OPÇÃO A: Renovar com fornecedor atual (R$6.200/mês)
— Menor custo | — Já conhece | — Sem migração
— Sem as features novas | — Suporte lento | — Sem SLA formal

OPÇÃO B: Trocar pro novo (R$7.800/mês)
— Features que precisa | — SLA 99.9% | — Suporte 24/7
— 25% mais caro | — Risco de migração | — Não conhece ainda

CUSTO DA INDECISÃO
Cada mês sem as features novas custa ~R$3k em trabalho manual
do time (estimativa baseada em 10h/mês à R$300/h).

IMPACTO EM 12 MESES
Opção A: R$74.4k + R$36k de trabalho manual = R$110.4k
Opção B: R$93.6k + R$0 trabalho manual = R$93.6k

💬 RECOMENDAÇÃO
Opção B é mais barata quando conta o custo escondido.
Mas negocie: use a proposta de R$6.200 do atual como argumento.
```

**Dica:** O assistente calcula custos escondidos que você não pensa.

---

### 24. Registrar decisão importante pra não esquecer

**Situação:** Tomou uma decisão e quer que fique documentada.

**O que mandar:**
```
/decisao
Decidimos não renovar com o fornecedor ABC. Vamos migrar pro
novo fornecedor XYZ até o final do mês. Alexandre cuida da migração.
```

**Output esperado:**
```
✅ Registrado em decisoes.md:

### 15/ABR/2026 — Troca de fornecedor de cloud
- **Decisão:** Não renovar com ABC. Migrar pra XYZ.
- **Contexto:** Reajuste de 40% inaceitável. XYZ tem melhor SLA.
- **Impacto:** Migração de todos os sistemas em 30 dias.
- **Expectativa de resultado:** Economia de R$2k/mês + SLA melhor.
- **Estimativa de custo:** R$5k de migração (one-time).
- **Envolvidos:** Alexandre (migração), Maria (jurídico, rescisão).
- **Prazo:** 30/abr/2026
- **Status:** Ativa

Pendências criadas:
- [ ] Alexandre: planejar migração | Prazo: 18/abr
- [ ] Maria: notificar ABC sobre não-renovação | Prazo: 17/abr
- [ ] Você: aprovar plano de migração | Prazo: 20/abr
```

**Variações:**
- "Decisão permanente: nunca aceitar reajuste acima de IPCA+5%"
- "Muda a decisão sobre X" — o assistente alerta sobre contradição
- "Que decisões eu tomei esse mês?" — lista cronológica

**Dica:** Decisões "permanentes" nunca são arquivadas. Viram regras do negócio.

---

### 25. Pedir opinião antes de decidir

**Situação:** Precisa tomar uma decisão mas quer ouvir uma perspectiva antes.

**O que mandar:**
```
To pensando em cortar 30% do orçamento de marketing pra investir
em produto. Faz sentido ou to sendo burro?
```

**Output esperado:**
```
💭 ANÁLISE

O QUE SEI SOBRE O CONTEXTO
- Seu CAC subiu 18% último trimestre (analise de março)
- 70% dos melhores clientes vieram de indicação, não de marketing
- Produto tem 3 features pedidas por clientes que não foram entregues
- Churn está subindo (decisoes.md: "retenção é prioridade")

A FAVOR DE CORTAR MARKETING
- Marketing não é seu principal canal de aquisição
- Investir em produto pode reduzir churn (que é seu maior problema)
- Features novas geram upsell (ticket subiu quando lançou a última)

CONTRA CORTAR MARKETING
- 30% é agressivo — pode secar o pipeline em 3-6 meses
- Tráfego pago tem efeito cumulativo, parar pode perder posição
- O time de marketing pode se desmotivar

💬 O QUE EU FARIA
Não cortar 30% de uma vez. Cortar 15% agora, realocar pra produto,
medir o impacto em 60 dias. Se o churn cair e o pipeline se mantiver,
cortar mais 15%. Decisão em fases reduz o risco.

Quer que eu modele o cenário financeiro dessa abordagem faseada?
```

**Dica:** O assistente cruza com suas decisões anteriores pra não te deixar contradizer o que já decidiu.

# CASOS DE USO — REUNIÕES

> 7 cenários para antes, durante e depois de reuniões.

---

### 7. Preparar reunião com desconhecido

**Situação:** Daqui 2 horas tem reunião com alguém que veio pelo LinkedIn. Sabe o nome e a empresa, mais nada.

**O que mandar:**
```
/reuniao com Rafael Mendes, da TechFlow
```

**O que o assistente faz:**
- Pesquisa TechFlow: site, LinkedIn, notícias, Reclame Aqui
- Pesquisa Rafael: cargo, LinkedIn, publicações recentes
- Busca interações anteriores (emails, menções)
- Identifica gancho de conversa

**Output esperado:**
```
🤝 REUNIÃO: Rafael Mendes — TechFlow
📋 Hoje, 14:00

SOBRE
Rafael é co-fundador e CRO da TechFlow, plataforma de automação
de vendas fundada em 2021 em São Paulo. ~45 funcionários, captou
R$8M em seed em 2024. Rafael tem 12 anos em vendas, passou pela
RD Station. LinkedIn: 4.200 conexões, publica sobre cultura de vendas.

🎯 GANCHO
TechFlow publicou ontem parceria com Pipedrive. Abrir com:
"Vi que fecharam com a Pipedrive, como estão integrando?"

HISTÓRICO CONOSCO
Primeiro contato. Nenhuma interação anterior.

PAUTA SUGERIDA
1. Entender o que a TechFlow faz
2. Explorar parceria ou integração
3. Alinhar próximos passos

PERGUNTAS ESTRATÉGICAS
- Qual problema vocês resolvem que ninguém resolve?
- Como funciona o modelo comercial?
- O que buscam nessa conversa?

📋 EXTRAS
Site: techflow.com.br
Reclame Aqui: 8.2, 91% respondidas
Glassdoor: 4.1/5
```

**Variações:**
- "/reuniao com o João do time" — puxa info de time.md
- "/reuniao amanhã" — prepara todas do dia seguinte
- "Prepara reunião com investidor" — formato mais formal com números

**Dica:** Após a reunião: "Decidimos fazer POC de 30 dias. Rafael manda proposta até sexta." O assistente registra.

---

### 8. Preparar reunião recorrente com o time

**Situação:** Daily de segunda. Quer chegar sabendo o que cobrar.

**O que mandar:**
```
Prepara minha daily de hoje. O que preciso cobrar do time?
```

**O que o assistente faz:**
- Lê pendencias.md filtrando por responsáveis do time
- Lê decisoes.md da última semana
- Puxa contexto-semanal.md

**Output esperado:**
```
📋 DAILY — PAUTA

COBRAR
- Thamer: relatório de vendas (pedido quarta, não entregou)
- Maria: retorno sobre o candidato (entrevista foi sexta)
- Alexandre: DRE de março (atrasado 5 dias)

INFORMAR
- Reunião com fornecedor ABC remarcada pra quinta
- Meta do mês: faltam R$38k (4 dias úteis)

DECISÕES PENDENTES
- Aprovação da nova ferramenta de CRM (aguardando cotações)

PERGUNTAR
- Lucas: como está o projeto do cliente X? Prazo é dia 20.
```

**Variações:**
- "Prepara a weekly" — visão mais ampla, inclui métricas
- "O que o Thamer me deve?" — filtra por pessoa
- "Gera ata da daily" — registra depois

**Dica:** Configure pra receber pauta da daily automaticamente às 8h45.

---

### 9. Registrar ata de reunião por áudio

**Situação:** Acabou a reunião. Você manda um áudio de 3 minutos com o que aconteceu.

**O que mandar:**
```
/ata
[manda áudio resumindo a reunião]
```

**O que o assistente faz:**
- Transcreve o áudio
- Organiza no formato de ata
- Extrai decisões e ações

**Output esperado:**
```
📋 ATA DE REUNIÃO

Data: 15/abr/2026
Participantes: Você, João (ABC Ltda), Maria (jurídico)
Assunto: Negociação de contrato de infraestrutura

CONTEXTO
Reunião de negociação do contrato de cloud. Terceira rodada.

DISCUSSÃO
- João apresentou nova proposta com reajuste de 15% (vs 40% anterior)
- Maria identificou 2 cláusulas que ainda precisam ajuste
- Prazo de migração reduzido de 60 pra 30 dias

DECISÕES
1. Aceitar reajuste de 15% — Responsável: você
2. Maria revisa cláusulas 8.3 e 12.1 — Prazo: quinta

AÇÕES
- [ ] Maria: enviar versão revisada do contrato | Prazo: quinta
- [ ] Você: aprovar versão final | Prazo: sexta
- [ ] João: agendar kickoff de migração | Prazo: próxima segunda

Quer que eu registre as decisões e ações na memória?
```

**Variações:**
- Manda notas por texto em vez de áudio
- "Manda a ata por email pros participantes"
- "Consolida as últimas 3 atas dessa negociação"

**Dica:** Peça pra enviar a ata por email direto. O assistente formata e envia pelo Gmail.

---

### 10. Follow-up após reunião importante

**Situação:** Ontem teve reunião com investidor. Quer mandar email de follow-up profissional.

**O que mandar:**
```
Manda follow-up pro Pedro (XYZ Capital) da reunião de ontem.
Agradecer, reforçar os pontos que discutimos, e confirmar
que mando o deck atualizado até sexta.
```

**O que o assistente faz:**
- Busca ata ou registros da reunião em sessoes/
- Consulta aprendizados.md pra tom de emails com investidores
- Rascunha o email

**Output esperado:**
```
🧠EMAIL

Para: Pedro Almeida (XYZ Capital)
Assunto: Follow-up — Reunião 14/abr

Pedro, obrigado pela reunião de ontem. Foi muito produtivo
alinhar a visão de crescimento e ouvir suas perspectivas
sobre o mercado.

Conforme conversamos, estamos focados em [pontos da reunião].
O modelo de unit economics que você pediu está em preparação
e envio junto com o deck atualizado até sexta.

Se precisar de algo antes disso, estou à disposição.

Abraço,
[seu nome]

---
Quer ajustar o tom ou posso enviar?
```

**Variações:**
- "Follow-up mais formal" — linguagem de investidor
- "Follow-up cobrando resposta" — tom de nudge gentil
- "Follow-up encerrando" — quando decidiu não seguir

**Dica:** O assistente adapta o tom conforme o destinatário. Investidor = mais formal. Time = mais direto.

---

### 11. Preparar reunião difícil (conflito, demissão, negociação tensa)

**Situação:** Você precisa ter uma conversa difícil com alguém do time que não está performando.

**O que mandar:**
```
Preciso ter uma conversa difícil com o Lucas. Ele não está
entregando faz 2 meses. Me ajuda a preparar.
```

**O que o assistente faz:**
- Busca info do Lucas em time.md
- Busca feedbacks anteriores em sessoes/ e decisoes.md
- Monta roteiro da conversa

**Output esperado:**
```
🤝 PREPARAÇÃO — CONVERSA DIFÍCIL COM LUCAS

CONTEXTO
Lucas está na empresa há 14 meses. Últimos 2 meses com entregas
atrasadas e qualidade abaixo do esperado. Último feedback formal:
há 3 meses (avaliação OK na época).

O QUE VOCÃ SABE
- 3 projetos atrasados no período
- Reclamação do cliente Y sobre qualidade
- Nenhum pedido de ajuda ou sinalização de problema

ROTEIRO SUGERIDO

1. ABERTURA (2 min)
"Lucas, quero conversar com você sobre como as coisas estão indo.
Não é uma conversa fácil, mas é importante pra nós dois."

2. FATOS (5 min)
Apresentar os dados concretos sem julgamento:
- Projetos X, Y e Z atrasados [datas]
- Feedback do cliente Y [o que disse]
- Diferença entre a performance dos últimos 2 meses vs antes

3. ESCUTA (10 min)
"O que está acontecendo? Tem algo que eu não estou vendo?"
— Deixe ele falar. Pode ser pessoal, pode ser burnout, pode ser falta de direção.

4. EXPECTATIVAS (5 min)
Definir claramente o que precisa mudar e em quanto tempo.

5. APOIO (3 min)
"O que eu posso fazer pra te ajudar a voltar pro seu melhor?"

6. ACORDO
Definir check-in em 2 semanas.

⚠️ CUIDADO
- Não compare com outros do time
- Foque em fatos, não em impressões
- Se ele trouxer problema pessoal, acolha antes de cobrar
```

**Variações:**
- "Conversa de demissão" — roteiro específico
- "Conversa sobre promoção" — tom diferente
- "Negociação tensa com fornecedor" — argumentos e limites

**Dica:** Após a conversa, mande o resumo. O assistente registra e cria pendência de check-in em 2 semanas.

---

### 12. Cancelar ou reagendar reunião com jeitinho

**Situação:** Tem reunião em 1h mas apareceu algo mais urgente. Precisa cancelar sem queimar a relação.

**O que mandar:**
```
Preciso cancelar a reunião das 14h com o João. Surgiu urgência.
Manda email educado reagendando pra semana que vem.
```

**O que o assistente faz:**
- Busca detalhes da reunião no Calendar
- Consulta aprendizados.md pra tom com esse tipo de contato
- Rascunha email de reagendamento

**Output esperado:**
```
🧠EMAIL

Para: João Silva (ABC Ltda)
Assunto: Reagendamento — reunião de hoje

João, boa tarde.

Surgiu uma demanda urgente que precisa da minha atenção
imediata e infelizmente não vou conseguir manter nossa
reunião de hoje às 14h.

Peço desculpas pelo curto prazo. Podemos reagendar pra
semana que vem? Tenho disponibilidade terça ou quarta
à tarde.

Abraço,
[seu nome]

---
Quer que eu envie e já sugira horários no Calendar?
```

**Variações:**
- "Cancela e não reagenda" — encerramento educado
- "Reagenda pra amanhã" — urgência menor
- "Avisa o time que cancelei a daily" — mensagem interna

**Dica:** O assistente pode verificar disponibilidade no Calendar e já sugerir 3 horários alternativos.

---

### 13. Preparar todas as reuniões do dia de uma vez

**Situação:** Dia cheio de reuniões. Quer preparar tudo de manhã.

**O que mandar:**
```
Prepara todas as minhas reuniões de hoje
```

**O que o assistente faz:**
- Puxa todas as reuniões do Calendar
- Pra cada uma: pesquisa, histórico, pauta sugerida
- Apresenta em sequência

**Output esperado:**
```
📋 SUAS 3 REUNIÕES DE HOJE

✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓—
09:00 — DAILY COM O TIME (30 min)
Cobrar: relatório do Thamer, retorno da Maria
Informar: meta do mês, reunião remarcada

✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓—
11:00 — CALL COM INVESTIDOR (Pedro, XYZ Capital)
Histórico: última call foi há 30 dias, pediu unit economics
Preparação: deck atualizado com números de março
Gancho: XYZ acabou de liderar rodada na fintech ABC

✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓✓—
14:00 — NEGOCIAÇÃO FORNECEDOR (João, ABC Ltda)
Histórico: 3ª rodada, reajuste caiu de 40% pra 15%
Pendência: cláusulas 8.3 e 12.1 (Maria revisando)
Objetivo: fechar em 15% com ajuste nas cláusulas

Quer briefing detalhado de alguma?
```

**Variações:**
- "Prepara as reuniões de amanhã"
- "Só a reunião com o investidor, em detalhes"
- "Quais reuniões posso cancelar essa semana?"

**Dica:** Peça isso todo dia às 8h como tarefa agendada.

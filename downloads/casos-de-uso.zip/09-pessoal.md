# CASOS DE USO — PESSOAL

> 6 cenários para vida pessoal, lembretes, viagens e organização.

---

### 51. Planejar viagem completa

**Situação:** Viagem de 3 dias pro Rio pra evento. Precisa de tudo organizado.

**O que mandar:**
```
Planeja minha viagem: Rio, terça a quinta, evento no centro de
convenções. Voo de SP, hotel próximo, e reserva de restaurante
pra jantar de negócios quarta.
```

**O que o assistente faz:** Pesquisa voos, hotéis, restaurantes. Consulta preferencias.md (localização vs preço vs conforto). Monta itinerário.

**Output esperado:**
```
✈️ VIAGEM — RIO DE JANEIRO
Terça 16/abr a Quinta 18/abr

VOO IDA — Terça
06:15 GRU — GIG (Latam 3421) — R$380 | Conexão direta
08:00 GRU — GIG (Gol 1892) — R$290 | Conexão direta
— Recomendo o de 06:15: chega cedo, aproveita manhã

VOO VOLTA — Quinta
18:30 GIG — GRU (Latam 3440) — R$340
20:00 GIG — GRU (Gol 1899) — R$280
— 18:30: chega em casa ~20h

HOTEL (3 opções)
1. Windsor Atlantica — R$420/noite | 10 min do centro de convenções
2. Hilton Copacabana — R$380/noite | 15 min
3. Ibis Santos Dumont — R$220/noite | 5 min
— Recomendo Windsor: custo-benefício + localização

RESTAURANTE QUARTA (jantar de negócios)
1. Oro — chef Felipe Bronze, premiado | R$250/pessoa
2. Lasai — contempor✓neo, intimista | R$280/pessoa
— Reservar com 48h de antecedência

CHECKLIST
- [ ] Comprar passagem
- [ ] Reservar hotel
- [ ] Reservar restaurante
- [ ] Baixar app do evento
- [ ] Confirmar jantar com o cliente

Quer que eu reserve algo?
```

**Variações:**
- "Viagem com a família" — hotéis com lazer, restaurantes kid-friendly
- "Viagem internacional" — inclui visto, seguro, c✓mbio
- "Viagem de última hora" — foca no que tem disponível

**Dica:** "Me lembra de fazer check-in 24h antes" — o assistente agenda o lembrete.

---

### 52. Lembrete recorrente

**Situação:** Quer ser lembrado de coisas que sempre esquece.

**O que mandar:**
```
Me lembra toda sexta de mandar flores pra minha esposa.
```

**O que o assistente faz:** Registra em pendencias.md como recorrente.

**Output esperado:**
```
✅ Lembrete recorrente criado:

📋 Toda sexta-feira: Mandar flores pra esposa
Primeiro lembrete: sexta 18/abr

Vou te lembrar toda sexta de manhã no briefing.
```

**Variações:**
- "Me lembra todo dia 1 de pagar o aluguel"
- "Me lembra 1 semana antes do aniversário do Marcos"
- "Me lembra de beber água a cada 2 horas" — não é o melhor uso, mas funciona

**Dica:** Lembretes recorrentes aparecem no /briefing do dia. Não precisa de app separado.

---

### 53. Organizar presente pra alguém

**Situação:** Aniversário do sócio semana que vem. Precisa de ideia de presente.

**O que mandar:**
```
Aniversário do Gabriel semana que vem. Sugere presente.
Ele gosta de vinho, churrasco e tecnologia. Budget até R$500.
```

**O que o assistente faz:** Pesquisa opções personalizadas. Consulta preferencias.md se tiver info sobre a pessoa.

**Output esperado:**
```
📋 SUGESTÕES DE PRESENTE — GABRIEL

1. Kit vinho premium (2 garrafas) — Wine.com.br
   R$350-450 | Entrega em 3 dias úteis
   Sugestão: Malbec argentino + Brunello italiano

2. Acessório de churrasco premium — Tramontina
   Kit faca + tábua personalizada — R$380
   Entrega: 5 dias | Personalização: 2 dias extras

3. Gadget tech — Echo Show 8 (Alexa com tela)
   R$499 | Entrega Prime 1 dia
   Ãtil pra casa, receitas, música

💬 RECOMENDAÇÃO
Kit vinho: mais pessoal e fácil de acertar. Encomenda hoje
pra chegar a tempo.

Quer que eu encomende?
```

**Variações:**
- "Presente pra cliente VIP" — mais formal
- "Presente de Natal pro time (20 pessoas, R$100 cada)" — em escala
- "Cartão de aniversário personalizado" — rascunha mensagem

---

### 54. Agendar compromissos pessoais

**Situação:** Precisa marcar dentista, renovar CNH e ir ao contador.

**O que mandar:**
```
Preciso marcar: dentista (limpeza), renovar CNH, e ir no contador
pra declaração de IR. Me ajuda a organizar.
```

**O que o assistente faz:** Verifica disponibilidade na agenda, sugere horários, cria lembretes.

**Output esperado:**
```
📋 COMPROMISSOS PESSOAIS

DENTISTA
- Última limpeza: [se souber] / Não registrada
- Sugestão: marcar pra semana que vem, horário de almoço
- Precisa ligar: (11) xxxx-xxxx (se tiver em preferencias.md)
- [ ] Pendência criada: marcar dentista | Prazo: sexta

CNH
- Vencimento: [busca se tiver na memória]
- Detran SP: agendamento online detran.sp.gov.br
- Documentos: RG, CPF, comprovante residência, CNH atual
- [ ] Pendência criada: agendar renovação | Prazo: essa semana

CONTADOR — IR
- Prazo limite: 31/maio
- Documentos pra levar: informes bancários, holerites, recibos
- Sugestão: marcar essa semana pra ter tempo de juntar docs
- [ ] Pendência criada: levar docs pro contador | Prazo: semana que vem

Quer que eu bloqueie horários na agenda pra cada um?
```

**Variações:**
- "Marca pra mim" — se tiver telefone/link de agendamento
- "O que preciso pra renovar CNH?" — pesquisa completa
- "Quando foi meu último check-up?" — consulta memória

---

### 55. Resumo do dia antes de dormir

**Situação:** Final do dia. Quer fechar o dia e não levar trabalho pra cama.

**O que mandar:**
```
Me dá o resumo do dia. O que fiz, o que ficou pendente, o que
tem amanhã.
```

**O que o assistente faz:** Cruza sessoes/ do dia, pendencias.md e agenda de amanhã.

**Output esperado:**
```
📋 RESUMO DO DIA — 15/ABR

FEITO HOJE ✅
- Aprovei proposta da agência
- Reunião com fornecedor: fechou 15% de reajuste
- Feedback pro Lucas
- 8 emails respondidos
- Brain dump organizado (3 tarefas novas)

FICOU PENDENTE
- Pesquisar CRM (pode ser amanhã)
- Responder email do cliente Y (não urgente)

AMANHÃ
09:00 Daily
10:00 Call investidor (preparação pronta)
14:00 Livre — bom pra deep work

🟡 Amanhã tem call com investidor. Quer que eu prepare o briefing
agora ou amanhã às 8h?

Boa noite. 📋
```

**Variações:**
- "O que não fiz que deveria?" — foco no que escapou
- "Transfere as pendências de hoje pra amanhã" — reagenda
- "Não me manda mais nada hoje" — modo silencioso até amanhã

**Dica:** Configure pra receber resumo todo dia às 20h automaticamente.

---

### 56. Brain dump pessoal (não é trabalho)

**Situação:** Coisas pessoais na cabeça: viagem da família, presente de aniversário, médico.

**O que mandar:**
```
Brain dump pessoal:
- preciso marcar viagem de férias com a família, julho, praia
- aniversário da minha mãe é dia 20, preciso de presente
- check-up médico, tá atrasado
- quero começar a ler mais, faz tempo que não leio
```

**O que o assistente faz:** Organiza, sugere prazos, cria pendências pessoais.

**Output esperado:**
```
🧠 PESSOAL ORGANIZADO

📋 AÇÕES
- [ ] Pesquisar viagem julho (praia, família) — essa semana
- [ ] Presente mãe (aniv dia 20) — comprar até dia 17
- [ ] Marcar check-up médico — essa semana
- [ ] Escolher livro pra começar — sem pressa

🟡 SUGESTÕES
- Viagem: quer que eu pesquise destinos? Quantas pessoas, budget?
- Presente mãe: que tipo de coisa ela gosta?
- Livro: quer recomendação baseada no que você gosta?

Registrar em pendencias.md?
```

**Variações:**
- "Só organiza, não registra" — não salva na memória
- "Pesquisa o destino de viagem agora" — /pesquisa
- "Me lembra do check-up toda semana até eu marcar" — insistente

**Dica:** O assistente separa pessoal de profissional na memória. Não mistura contextos.

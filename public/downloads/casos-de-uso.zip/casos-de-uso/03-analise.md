# CASOS DE USO — ANÁLISE

> 7 cenários para analisar documentos, dados e propostas.

---

### 14. Analisar contrato antes de assinar

**Situação:** Recebeu contrato de 15 páginas. Precisa decidir até amanhã.

**O que mandar:**
```
/analise
[anexa o PDF]
```

**Output esperado:**
```
📄 ANÁLISE DE CONTRATO

PARTES: Sua Empresa × Fornecedor ABC Ltda
OBJETO: Serviços de infraestrutura cloud
VALOR: R$12.500/mês, reajuste anual IGPM
PRAZO: 24 meses, renovação automática

⚠️ RISCOS
1. Cláusula 8.3 — Multa de 6 meses na rescisão antecipada
   Sugestão: negociar pra 3 meses
2. Cláusula 12.1 — SLA 99.5% sem penalidade se descumprirem
   Sugestão: incluir crédito por downtime
3. Cláusula 15.2 — Reajuste IGPM sem teto
   Sugestão: trocar pra IPCA ou teto de 10%

✅ FAVORÁVEIS
- Migração gratuita inclusa
- Suporte 24/7, SLA 2h

💬 RECOMENDAÇÃO
Negociar os 3 riscos antes de assinar. Contrato favorável se ajustado.
```

**Variações:**
- "Compara com o contrato anterior" → se tiver em anexos/
- "Me mostra só os riscos" → versão resumida
- "Prepara email pro advogado com os pontos" → gera email com os itens pra revisão jurídica

**Dica:** "Salva em anexos/contratos/" e na próxima negociação o assistente puxa o histórico.

---

### 15. Analisar proposta comercial com pesquisa do fornecedor

**Situação:** Recebeu proposta de um fornecedor novo. Quer saber se o preço é justo.

**O que mandar:**
```
/analise
[anexa a proposta]
Pesquisa esse fornecedor pra mim também.
```

**Output esperado:**
```
📄 ANÁLISE DE PROPOSTA

DE: XYZ Soluções
VALOR: R$8.500/mês
CONDIÇÕES: Contrato de 12 meses, pagamento boleto, sem multa rescisória

SOBRE O FORNECEDOR
XYZ Soluções, fundada em 2018, ~30 funcionários, São Paulo.
Especializada em automação de processos pra PMEs. CEO: Carlos
Mendes, ex-gerente da Totvs. Principais clientes: empresas de
médio porte no setor de varejo.

🔍 REPUTAÇÃO
- Reclame Aqui: nota 7.8, 56 reclamações, 85% respondidas
- Google: 4.2/5 (42 avaliações)
- Glassdoor: 3.8/5 (não é ótimo, queixas sobre gestão)

COMPARAÇÃO
Você paga R$6.200/mês pro fornecedor atual (contrato vence em 60 dias).
A proposta é 37% mais cara mas inclui 3 módulos que hoje são extras.

💡 ARGUMENTOS DE NEGOCIAÇÃO
1. "O concorrente de vocês oferece por R$7.200 com escopo similar"
2. "Nosso contrato atual é R$6.200. Pra trocar preciso de valor competitivo"
3. "Se fechar anual, consigo desconto? Estou avaliando outras 2 propostas"

💬 RECOMENDAÇÃO
Negociar pra R$7.000-7.500. A reputação é ok mas não excelente.
Pedir referência de 2 clientes antes de fechar.
```

**Dica:** Peça "pesquisa 2 alternativas" e o assistente busca concorrentes do fornecedor.

---

### 16. Analisar relatório financeiro (DRE, balancete)

**Situação:** O financeiro mandou o DRE de março. Precisa entender rápido.

**O que mandar:**
```
/analise
[anexa planilha ou PDF do DRE]
```

**Output esperado:**
```
📊 ANÁLISE FINANCEIRA

PERÍODO: Março/2026
RESUMO: Faturamento R$148k (meta era R$150k, 98.7% atingido).

ANÁLISE
Receita ficou 1.3% abaixo da meta, mas cresceu 12% vs março do
ano anterior. O ticket médio subiu de R$2.800 pra R$3.100,
indicando sucesso no upsell. Porém, o número de clientes ativos
caiu de 54 pra 48 — a retenção está piorando. O CAC subiu 18%
por causa do investimento em tráfego pago que ainda não maturou.
A margem bruta caiu de 68% pra 63%, puxada pelo aumento de
custo com cloud (reajuste de janeiro). Se a tendência de churn
continuar, o gap se agrava no Q3.

📈 POSITIVOS
- Ticket médio subiu 10.7% → upsell funcionando
- Crescimento 12% YoY → empresa crescendo

📉 ATENÇÃO
- Clientes ativos caíram 11% → retenção piorando
- CAC subiu 18% → custo de aquisição alto
- Margem bruta caiu 5 pontos → pressão de custos

❓ PERGUNTAS PRO FINANCEIRO
- O churn de março é pontual ou tendência?
- O investimento em tráfego já está gerando pipeline?
- Qual a previsão de impacto do reajuste de cloud no ano?
```

**Variações:**
- "Compara com o mês passado" → evolução mês a mês
- "Me mostra só o que está piorando" → foco em problemas
- "Prepara 3 slides com esses dados pro board" → gera apresentação

**Dica:** Peça análise todo mês. O assistente começa a identificar tendências automaticamente.

---

### 17. Analisar currículo pra uma vaga

**Situação:** RH mandou 5 currículos pra vaga de gerente comercial.

**O que mandar:**
```
Analisa esses 5 currículos pra vaga de gerente comercial.
Critérios: experiência em SaaS B2B, gestão de time de vendas,
e track record de crescimento.
[anexa os 5 PDFs]
```

**Output esperado:**
```
📋 ANÁLISE DE CANDIDATOS — Gerente Comercial

1️⃣ ANA PAULA (⭐ RECOMENDADO)
   8 anos em vendas B2B SaaS. Gerente na RD Station (3 anos).
   Time de 12 pessoas. Cresceu a operação 3x.
   ✅ Experiência SaaS | ✅ Gestão de time | ✅ Track record
   ⚠️ Salário atual provavelmente alto

2️⃣ MARCOS
   6 anos em vendas. Coordenador na Resultados Digitais.
   Nunca foi gerente, mas liderou 5 SDRs informalmente.
   ✅ SaaS | ⚠️ Nunca gerenciou formalmente | ✅ Crescimento

3️⃣ JULIANA
   10 anos em vendas, mas em varejo. Migrou pra tech há 1 ano.
   ⚠️ Pouca experiência SaaS | ✅ Gestão | ✅ Perfil forte

4️⃣ PEDRO
   4 anos. Muito júnior pra a posição.
   ❌ Sem experiência de gestão

5️⃣ CARLA
   7 anos, mas toda experiência em empresa familiar.
   ⚠️ Transição cultural pode ser difícil

💬 RECOMENDAÇÃO
Chamar Ana Paula e Marcos pra entrevista. Ana Paula é a mais
forte mas pode ser cara. Marcos é aposta com potencial.
```

**Dica:** Peça "prepara perguntas de entrevista pra Ana Paula" e o assistente monta baseado no currículo.

---

### 18. Comparar duas propostas lado a lado

**Situação:** Duas propostas de fornecedores diferentes pro mesmo serviço.

**O que mandar:**
```
Compara essas duas propostas e me diz qual é melhor pra gente.
[anexa as 2 propostas]
```

**Output esperado:**
```
📊 COMPARATIVO

                    FORNECEDOR A        FORNECEDOR B
Preço mensal        R$8.500             R$7.200
Contrato            12 meses            6 meses
Multa rescisória    3 meses             Sem multa
SLA                 99.9%               99.5%
Suporte             24/7                Horário comercial
Migração            Gratuita            R$5.000
Reajuste            IPCA                IGPM

✅ FORNECEDOR A É MELHOR EM:
- SLA mais robusto (99.9% vs 99.5%)
- Suporte 24/7
- Migração gratuita

✅ FORNECEDOR B É MELHOR EM:
- 15% mais barato
- Contrato mais curto (menos risco)
- Sem multa de rescisão

💬 RECOMENDAÇÃO
Fornecedor B se o objetivo é testar. Fornecedor A se quer
estabilidade. Negociar com A pra reduzir preço usando a
proposta de B como argumento.
```

**Dica:** "Manda email pro Fornecedor A usando o preço do B como argumento."

---

### 19. Resumir documento longo rapidamente

**Situação:** Recebeu relatório de 40 páginas. Tem 5 minutos.

**O que mandar:**
```
Resume esse documento em 1 página. Foco no que importa pra mim.
[anexa o PDF]
```

**Output esperado:**
```
📄 RESUMO EXECUTIVO

DOCUMENTO: Relatório de Mercado — Setor de Tecnologia Q1/2026
AUTOR: Consultoria XYZ | 42 páginas

CONCLUSÃO PRINCIPAL
O mercado de SaaS B2B no Brasil cresceu 23% no Q1 mas o CAC
médio subiu 31%. Empresas que investiram em retenção cresceram
2x mais que as focadas em aquisição.

3 DADOS MAIS RELEVANTES PRA VOCÊ
1. Churn médio do setor é 4.5%/mês (seu é mais alto — atenção)
2. Ticket médio subiu 15% em empresas com upsell estruturado
3. IA reduziu custo de atendimento em 40% nos early adopters

O QUE MUDA PRA SUA EMPRESA
- Confirma que retenção > aquisição na sua fase
- Oportunidade de IA no atendimento (ainda não faz)
- Seu ticket pode subir se estruturar upsell

VALE LER NA ÍNTEGRA?
Páginas 12-18 (análise de churn) e 34-38 (cases de IA). O resto
é contexto de mercado que você já sabe.
```

**Variações:**
- "Traduz esse documento" → tradução + resumo
- "Extrai os dados numéricos" → só os números
- "O que esse documento diz que contradiz o que a gente faz?" → análise crítica

**Dica:** Peça "salva o resumo em anexos/" pra consultar depois sem reabrir o PDF.

---

### 20. Analisar email recebido e sugerir resposta

**Situação:** Recebeu email complexo de um cliente insatisfeito.

**O que mandar:**
```
Analisa esse email e me diz como responder.
[cola o email ou encaminha]
```

**Output esperado:**
```
📧 ANÁLISE DO EMAIL

REMETENTE: Carlos, diretor da Empresa Y (cliente há 8 meses)
TOM: Frustrado mas profissional. Não é agressivo.

O QUE ELE QUER
1. Explicação pro downtime de 4h na semana passada
2. Desconto proporcional no mês
3. Garantia que não vai acontecer de novo

O QUE ESTÁ NAS ENTRELINHAS
Ele está avaliando concorrentes. A frase "estamos avaliando
nossas opções" é um sinal. Se não resolver bem, pode sair.

CONTEXTO (da memória)
- Cliente desde ago/2025, ticket de R$4.500/mês
- Nenhuma reclamação anterior registrada
- Renova em 2 meses

💬 SUGESTÃO DE RESPOSTA
Tom: empático, transparente, proativo. Assumir o erro sem
se justificar demais. Oferecer crédito + plano de ação.

Quer que eu rascunhe o email de resposta?
```

**Dica:** Peça as duas versões (firme e diplomática) e escolha a que melhor encaixar.

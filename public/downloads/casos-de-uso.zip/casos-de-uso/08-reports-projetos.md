# CASOS DE USO — REPORTS E GESTÃO DE PROJETOS

> 6 cenários para relatórios, acompanhamento de projetos e visão executiva.

---

### 45. Relatório semanal consolidado

**Situação:** Sexta-feira. Quer um resumo da semana pra fechar.

**O que mandar:**
```
Me dá o relatório da semana.
```

**O que o assistente faz:** Cruza decisoes.md, pendencias.md, sessoes/ da semana, emails e agenda.

**Output esperado:**
```
📊 RELATÓRIO SEMANAL — 11 a 15/ABR/2026

DECISÕES TOMADAS (3)
1. Trocar fornecedor de cloud (ABC → XYZ) — migração até 30/abr
2. Aprovar contratação de 2 vendedores — início 01/mai
3. Rejeitar parceria com TechFlow — condições desfavoráveis

PENDÊNCIAS RESOLVIDAS (5)
✅ Proposta da agência aprovada
✅ DRE de março revisado
✅ Entrevista candidato realizada
✅ Contrato ABC negociado (15% vs 40%)
✅ Feedback pro Lucas dado

PENDÊNCIAS NOVAS (3)
- [ ] Alexandre: plano de migração | Prazo: 18/abr
- [ ] Maria: notificar ABC | Prazo: 17/abr
- [ ] Você: aprovar plano migração | Prazo: 20/abr

PENDÊNCIAS ATRASADAS (1)
- [ ] Pesquisar CRM — sem prazo definido

REUNIÕES (7)
Daily (5), call investidor (1), negociação fornecedor (1)

NÚMEROS
- Faturamento abril até agora: R$112k (meta R$150k, 74.7%)
- Clientes ativos: 48
- Pipeline: R$85k em negociação

PRÓXIMA SEMANA
- Board na sexta (preparar números)
- Migração cloud começa
- 2 entrevistas marcadas
```

**Variações:**
- "Relatório do mês" → visão mensal consolidada
- "Relatório só de vendas" → filtra por área
- "Manda esse relatório por email pro sócio" → formata e envia

**Dica:** Configure pra receber toda sexta às 17h automaticamente.

---

### 46. Status de projeto em andamento

**Situação:** Tem um projeto importante e quer saber onde está.

**O que mandar:**
```
Qual o status do projeto de migração de cloud? O que falta?
```

**O que o assistente faz:** Busca em decisoes.md, pendencias.md e sessoes/ tudo sobre "migração" e "cloud".

**Output esperado:**
```
📋 STATUS — MIGRAÇÃO DE CLOUD

DECISÃO: Trocar ABC → XYZ (decidido 15/abr)
PRAZO: 30/abr (15 dias restantes)
RESPONSÁVEL: Alexandre

FEITO ✅
- Contrato com XYZ assinado
- Notificação pra ABC enviada
- Plano de migração aprovado

EM ANDAMENTO 🔄
- Alexandre configurando ambiente de testes (previsão: 20/abr)
- Maria fazendo rescisão formal com ABC

PENDENTE ❌
- Teste de carga no novo ambiente
- Migração dos dados (depende do teste)
- DNS e redirecionamento
- Comunicar o time sobre janela de manutenção

RISCOS
- Se o teste de carga atrasar, a migração dos dados empurra pra
  última semana e fica sem margem de erro
- ABC pode cobrar multa proporcional (Maria verificando)

PRÓXIMO MARCO
Teste de carga concluído até 22/abr. Se der certo, migração dia 27.
```

**Variações:**
- "Status de todos os projetos" → lista geral
- "O que pode atrasar?" → foco em riscos
- "Manda update pro time sobre o projeto" → comunicado

**Dica:** Peça "me lembra de perguntar do projeto todo dia" e o assistente cobra automaticamente.

---

### 47. Preparar report pro board ou investidor

**Situação:** Reunião de board sexta. Precisa dos números organizados.

**O que mandar:**
```
Prepara o report pro board de sexta. Inclui: faturamento,
clientes, churn, pipeline, contratações e decisões do mês.
```

**O que o assistente faz:** Puxa dados de empresa.md, DREs anteriores, decisoes.md, time.md.

**Output esperado:**
```
📊 BOARD REPORT — ABRIL/2026

FINANCEIRO
- Faturamento: R$148k (meta R$150k, 98.7%)
- Crescimento YoY: +12%
- Margem bruta: 63% (vs 68% anterior — pressão de custos cloud)
- Caixa: R$XXk (X meses de runway)

CLIENTES
- Ativos: 48 (vs 54 mês anterior)
- Churn: 11% no mês (acima da média)
- Ticket médio: R$3.100 (+10.7% vs anterior)
- NPS: não medido (propor medir no Q3)

PIPELINE
- R$85k em negociação
- 3 enterprise em fase final
- Ciclo médio: 28 dias

TIME
- 4 contratações, 2 saídas
- Headcount: 23 → 25
- Vagas abertas: gerente comercial

DECISÕES ESTRATÉGICAS DO MÊS
1. Troca de fornecedor cloud (economia R$2k/mês + SLA melhor)
2. 2 novos vendedores (início maio)
3. Parceria TechFlow rejeitada

DESAFIOS
- Churn subindo — retenção é prioridade Q3
- CAC alto — investimento em tráfego ainda não maturou
- Margem pressionada pelo reajuste de cloud (migração resolve)

PRÓXIMO MÊS
- Meta: R$160k
- Foco: onboarding dos 2 vendedores
- Marco: migração cloud concluída
```

**Variações:**
- "Report pro investidor" → mais formal, inclui unit economics
- "Report de 1 página" → versão executiva resumida
- "Monta 5 slides com esses dados" → gera apresentação

**Dica:** Salve em anexos/apresentacoes/ e no próximo board o assistente puxa histórico pra comparar.

---

### 48. Acompanhar OKRs ou metas do trimestre

**Situação:** Meio do trimestre. Quer saber se as metas estão no caminho.

**O que mandar:**
```
Como estão nossos OKRs do Q2? Tamo no caminho?
```

**O que o assistente faz:** Busca metas registradas em objetivos.md e cruza com dados atuais.

**Output esperado:**
```
📊 OKRs Q2/2026 — STATUS (50% do trimestre)

OKR 1: CRESCER RECEITA PRA R$180K/MÊS
KR1: Faturamento médio R$180k → Atual: R$148k (82%) 🟡
KR2: 5 clientes enterprise → Atual: 2 fechados (40%) 🟡
KR3: Ticket médio R$3.500 → Atual: R$3.100 (88%) 🟢
Prognóstico: RISCO. Precisa acelerar enterprise.

OKR 2: REDUZIR CHURN PRA 5%
KR1: Churn mensal <5% → Atual: 11% 🔴
KR2: NPS >50 → Não medido ❓
KR3: Onboarding <7 dias → Atual: 12 dias 🟡
Prognóstico: CRÍTICO. Churn é 2x a meta.

OKR 3: ESTRUTURAR TIME COMERCIAL
KR1: Contratar gerente → Em processo 🟡
KR2: 2 vendedores novos → Aprovado, início maio 🟢
KR3: Playbook comercial documentado → 60% pronto 🟡
Prognóstico: NO CAMINHO.

💬 RESUMO
1 OKR no caminho, 1 em risco, 1 crítico. Prioridade:
resolver churn antes de investir mais em aquisição.
```

**Variações:**
- "Atualiza o KR1 do OKR 2 pra 8%" → ajusta em objetivos.md
- "O que precisa acontecer pra bater o OKR 1?" → plano de ação
- "Compara com Q1" → evolução trimestral

**Dica:** Peça acompanhamento quinzenal automático.

---

### 49. Consolidar updates do time em um só lugar

**Situação:** Cada pessoa do time manda update por canal diferente. Quer consolidar.

**O que mandar:**
```
Consolida os updates do time dessa semana. Thamer mandou por email,
Maria por WhatsApp, Alexandre no Slack.
```

**O que o assistente faz:** Puxa emails, mensagens e menções recentes das pessoas do time.

**Output esperado:**
```
📋 UPDATES DO TIME — SEMANA 15/ABR

THAMER (Comercial)
- Pipeline: R$85k em negociação
- 3 reuniões com enterprise marcadas
- Pediu aprovação pra desconto de 15% no cliente Z
Status: performando bem, precisa da sua aprovação

MARIA (RH)
- 5 currículos recebidos pra gerente comercial
- Onboarding do dev novo finalizado
- Pediu budget pra treinamento do time
Status: entregando, aguarda decisão sobre budget

ALEXANDRE (Financeiro)
- DRE de março finalizado (atrasou 5 dias)
- Projeção de caixa em andamento
- Alerta: conta de cloud subiu 18%
Status: atrasando entregas, conversar

LUCAS (Produto)
- Sem update essa semana
Status: ⚠️ sem visibilidade — cobrar
```

**Variações:**
- "Consolida só vendas" → filtra por área
- "Manda email pro time pedindo update" → cobra de quem não mandou
- "Transforma num slide" → formato de apresentação

**Dica:** Configure pra receber consolidação toda sexta. O assistente vai atrás das informações.

---

### 50. Criar dashboard de KPIs do mês

**Situação:** Quer uma visão rápida dos números mais importantes.

**O que mandar:**
```
Monta um dashboard com os KPIs do mês: faturamento, clientes ativos,
churn, ticket médio, CAC, pipeline.
```

**O que o assistente faz:** Puxa dados de empresa.md, DREs, análises anteriores.

**Output esperado:**
```
📊 DASHBOARD — ABRIL/2026

RECEITA
█████████████████░░░ R$148k / R$150k (98.7%)

CLIENTES ATIVOS
████████████████░░░░ 48 (meta: 55) ⚠️

CHURN
████████████░░░░░░░░ 11% (meta: <5%) 🔴

TICKET MÉDIO
██████████████████░░ R$3.100 (meta: R$3.500) 🟡

CAC
████████████████░░░░ R$1.200 (meta: <R$1.000) 🟡

PIPELINE
█████████████████░░░ R$85k em negociação

TENDÊNCIA
📈 Ticket subindo (bom)
📉 Clientes caindo (ruim)
📈 Pipeline crescendo (bom)
📉 Churn disparando (crítico)

💬 PRIORIDADE #1: Resolver churn. É o número que mais
impacta todos os outros.
```

**Variações:**
- "Dashboard por área" → comercial, produto, financeiro
- "Compara com mês passado" → evolução
- "Manda pro sócio" → formata e envia

**Dica:** "Manda meu dashboard todo dia 1 do mês" como tarefa agendada.

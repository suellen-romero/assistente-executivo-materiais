# CASOS DE USO — MANHÃ

> 6 cenários para começar o dia com o assistente.

---

### 1. Briefing completo do dia

**Situação:** Você acordou, pegou o celular, quer saber o que te espera hoje sem abrir 4 apps.

**O que mandar:**
```
/briefing
```

**O que o assistente faz:**
- Acessa Gmail e lista os emails mais importantes
- Acessa Google Calendar e puxa compromissos de hoje
- Lê memoria/pendencias.md e identifica atrasadas
- Lê memoria/contexto-semanal.md pra contexto relevante

**Output esperado:**
```
📧 EMAILS (12 novos, 3 importantes)
🔴 João Silva (fornecedor) — Reajuste de contrato → Precisa responder hoje
🟡 Maria (RH) — Candidato pra vaga de analista → Confirmar entrevista
🟡 Newsletter Exame — Matéria sobre seu setor → Ler quando puder

📅 AGENDA
09:00 — Daily com o time (30 min)
11:00 — Call com investidor (Pedro, XYZ Capital) → Preparação pronta
14:00 — Reunião com fornecedor (João, ABC Ltda) → Contrato em negociação
16:00 — Livre

⚡ PENDÊNCIAS (8 abertas, 2 atrasadas)
🔴 Aprovar proposta da agência (3 dias de atraso)
🔴 Responder email do contador (2 dias)
🟡 Revisar apresentação pra quinta

💡 CONTEXTO
Semana de fechamento. Meta do mês: R$150k, faltam R$38k.
Reunião de board marcada pra sexta — preparar números.
```

**Variações:**
- "Me dá o briefing da semana" → visão dos próximos 5 dias
- "O que tem de urgente?" → só pendências atrasadas e emails urgentes
- "Briefing rápido" → versão resumida em 5 linhas

**Dica:** Use /briefing todo dia no mesmo horário. Em 1 semana o assistente já sabe seu padrão e prioriza melhor.

---

### 2. Priorizar o dia quando tudo parece urgente

**Situação:** Você tem 15 coisas pra fazer e não sabe por onde começar.

**O que mandar:**
```
Tenho muita coisa pra fazer hoje e to travado. Me ajuda a priorizar.
```

**O que o assistente faz:**
- Lê pendencias.md e agenda do dia
- Classifica por urgência real (prazo) vs importância (impacto)
- Propõe ordem de execução com horários

**Output esperado:**
```
📋 SEU DIA PRIORIZADO

FAÇA PRIMEIRO (antes das 10h)
1. Aprovar proposta da agência — 3 dias atrasada, trava o projeto
2. Responder email do contador — vence hoje, risco fiscal

FAÇA ENTRE REUNIÕES (10h-14h)
3. Revisar apresentação pra quinta — 20 min
4. Validar contrato do fornecedor — depende da reunião das 14h

FAÇA NO FINAL DO DIA (16h+)
5. Ler relatório de vendas — informativo
6. Responder emails não-urgentes

PODE ESPERAR
7. Atualizar planejamento Q3
8. Pesquisar ferramenta de CRM

Quer que eu bloqueie horários na agenda?
```

**Variações:**
- "Se eu só pudesse fazer 3 coisas hoje, quais?"
- "Prioriza minha semana"
- "O que posso adiar?"

**Dica:** Depois de priorizar, diga "bloqueia na agenda" e o assistente cria os blocos.

---

### 3. Limpar a caixa de email em 5 minutos

**Situação:** 47 emails não lidos. Não quer gastar 1 hora nisso.

**O que mandar:**
```
Me mostra os emails que preciso responder hoje. O resto pode esperar.
```

**O que o assistente faz:**
- Acessa Gmail e classifica por urgência
- Separa: precisa responder, precisa ler, pode ignorar

**Output esperado:**
```
📧 TRIAGEM DE EMAILS

🔴 RESPONDER HOJE (3)
1. João Silva — Reajuste contrato — Quer resposta até amanhã
2. Maria RH — Candidato entrevista — Confirmar horário
3. Contador — Documentos fiscais — Prazo legal é sexta

🟡 LER ESSA SEMANA (5)
4. Relatório de vendas — Thamer
5. Newsletter do setor
6-8. Emails internos informativos

⚪ IGNORAR (39)
Newsletters, promoções, notificações automáticas.
Quer que eu desinscreva de alguma lista?
```

**Variações:**
- "Emails do João" → filtra por remetente
- "Emails sobre o contrato" → filtra por assunto
- "Responde todos os emails simples pra mim" → rascunha em lote

**Dica:** Peça "me desinscreve de tudo que é newsletter" e o assistente limpa sua caixa permanentemente.

---

### 4. Checar pendências atrasadas

**Situação:** Quer saber se alguma bomba estourou enquanto dormia.

**O que mandar:**
```
/pendencias
```

**O que o assistente faz:**
- Lê memoria/pendencias.md
- Classifica por prazo e impacto do atraso

**Output esperado:**
```
📋 PENDÊNCIAS

🔴 ATRASADAS (2)
- [ ] Aprovar proposta da agência | 3 dias de atraso
  ⚠️ Impacto: agência parou o projeto
- [ ] Responder contador | 2 dias de atraso
  ⚠️ Impacto: risco de multa fiscal

🟡 ESTA SEMANA (4)
- [ ] Revisar apresentação | 17/abr
- [ ] Validar contrato | 18/abr
- [ ] Feedback pro Lucas | 18/abr
- [ ] Confirmar reserva jantar | 16/abr

Total: 9 abertas | 2 atrasadas
Quer marcar alguma como concluída?
```

**Variações:**
- "O que atrasou?" → só as atrasadas
- "Pendências do time" → filtra por responsável
- "Marca a proposta como concluída"

**Dica:** /pendencias toda segunda de manhã vira seu ritual de início de semana.

---

### 5. Planejar a semana em 15 minutos

**Situação:** Segunda-feira. Quer clareza dos próximos 5 dias.

**O que mandar:**
```
Me ajuda a planejar a semana.
```

**O que o assistente faz:**
- Puxa agenda de segunda a sexta
- Cruza com pendencias.md
- Identifica conflitos e buracos
- Sugere blocos de foco

**Output esperado:**
```
📅 SUA SEMANA

SEGUNDA
09:00 Daily | 14:00 Reunião fornecedor | Resto livre
→ Resolver 2 pendências atrasadas de manhã

TERÇA
09:00 Daily | 10:00 Call investidor | 14h-17h livre
→ Bloco de foco pra apresentação

QUARTA
Dia livre de reuniões
→ Deep work: planejamento Q3

QUINTA
09:00 Daily | 10:00 Entrevista | 19:30 Jantar cliente
→ Confirmar restaurante, preparar reunião do jantar

SEXTA
09:00 Daily | 14:00 Board
→ Preparar números quinta à tarde

⚡ ALERTAS
- 2 pendências atrasadas
- Board sexta sem preparação
- Nenhum tempo de foco bloqueado
```

**Variações:**
- "Bloqueia 2h de foco na quarta"
- "O que posso cancelar?"
- "Manda planejamento toda segunda às 7h" → tarefa agendada

**Dica:** Combine com /briefing diário e /pendencias semanal.

---

### 6. Brain dump matinal por áudio

**Situação:** No carro, 10 coisas na cabeça, não quer perder nada.

**O que mandar:**
```
[áudio de 2-3 minutos despejando tudo]
```

**O que o assistente faz:**
- Transcreve com Whisper
- Organiza por tema
- Classifica: tarefa, ideia, decisão, referência

**Output esperado:**
```
🧠 BRAIN DUMP ORGANIZADO

📋 TAREFAS
- [ ] Ligar pro advogado sobre contrato → hoje
- [ ] Pedir relatório pro Thamer → hoje
- [ ] Marcar jantar com Marcos → essa semana

💡 IDEIAS
- Programa de indicação pra clientes
- Testar anúncios no YouTube

📞 PESSOAS
- Marcos: jantar, faz tempo que não falam
- Advogado: cláusula do contrato

Quer que eu registre as tarefas em pendencias.md?
```

**Variações:**
- 3 áudios curtos ao longo do dia → consolida no final
- "Organiza tudo que mandei hoje"
- /braindump por texto

**Dica:** Brain dump por áudio de manhã + /pendencias no fim do dia = nada se perde.

# CASOS DE USO — PESQUISA

> 5 cenários para pesquisar, comparar e encontrar opções.

---

### 34. Restaurante pra jantar de negócios

**Situação:** Jantar com cliente importante quinta. Precisa impressionar.

**O que mandar:**
```
/pesquisa restaurante japonês ou italiano, zona sul SP,
até R$250/pessoa, 4 pessoas, quinta à noite
```

**O que o assistente faz:** Pesquisa na web, cruza com preferencias.md, compara avaliações. Inclui prazo de reserva, frete, pagamento, link.

**Output esperado:** Top 3 opções com preço, avaliação, prazo de reserva, endereço, link e recomendação final.

**Dica:** "Vou de Kinoshita" → registra em preferencias.md pra próxima vez.

---

### 35. Fornecedor pra serviço que nunca contratou

**Situação:** Precisa de empresa de limpeza pro escritório. Nunca contratou.

**O que mandar:**
```
/pesquisa empresa de limpeza comercial em [cidade],
escritório de 200m², 3x por semana
```

**O que o assistente faz:** Pesquisa opções, verifica Reclame Aqui, Google, pede cotação se possível.

**Output esperado:**
```
🔍 PESQUISA: Limpeza comercial

1️⃣ CLEAN PRO
   Especializada em escritórios. 8 anos no mercado.
   Preço: R$1.800-2.200/mês (3x semana)
   Prazo pra iniciar: 5 dias úteis
   Contrato: mínimo 3 meses
   Pagamento: boleto ou PIX
   Reclame Aqui: 8.5
   Contato: (11) 9xxxx-xxxx

2️⃣ LIMPA FÁCIL
   Mais barata, time menor.
   Preço: R$1.400-1.600/mês
   Contrato: sem fidelidade
   Reclame Aqui: 7.2
   ...

3️⃣ SERVICE CLEAN
   Premium, inclui produtos.
   Preço: R$2.500-3.000/mês
   ...

💬 RECOMENDAÇÃO
Clean Pro: melhor custo-benefício. Pedir visita técnica antes.
```

**Variações:**
- "Pesquisa contabilidade" → foco em especialização e preço
- "Pesquisa advogado trabalhista" → foco em experiência e casos
- "Pesquisa seguro empresarial" → foco em cobertura e prêmio

---

### 36. Hotel pra viagem de negócios

**Situação:** Viagem pra Rio semana que vem. Precisa de hotel.

**O que mandar:**
```
/pesquisa hotel no Rio, próximo ao centro de convenções,
terça a quinta, quarto single, até R$500/noite
```

**O que o assistente faz:** Pesquisa opções com localização, preço, avaliação, cancelamento.

**Output esperado:** Top 3 hotéis com preço/noite, distância do local, avaliação, política de cancelamento, link pra reserva.

**Dica:** Se fala com frequência "priorizo localização", o assistente já sabe e ordena por proximidade.

---

### 37. Ferramenta ou software pra resolver um problema

**Situação:** Precisa de CRM e não sabe qual escolher.

**O que mandar:**
```
/pesquisa CRM pra time de 8 vendedores, B2B SaaS,
orçamento até R$500/mês, precisa integrar com Gmail
```

**O que o assistente faz:** Pesquisa, compara features, preço, e cruza com as necessidades.

**Output esperado:**
```
🔍 PESQUISA: CRM B2B

1️⃣ PIPEDRIVE
   Mais popular pra PME. Interface intuitiva.
   R$290/mês (8 usuários, plano Professional)
   ✅ Integra Gmail | ✅ Pipeline visual | ✅ App mobile
   ❌ Relatórios limitados no plano básico
   Free trial: 14 dias
   Link: pipedrive.com

2️⃣ HUBSPOT CRM
   Gratuito pra funcionalidades básicas.
   R$0 (básico) ou R$450/mês (plano Starter, 8 usuários)
   ✅ Gmail nativo | ✅ Marketing incluso | ✅ Muito completo
   ❌ Curva de aprendizado alta | ❌ Caro pra escalar
   ...

3️⃣ RD STATION CRM
   Brasileiro, integra com RD Marketing.
   R$320/mês (8 usuários)
   ✅ Suporte em PT | ✅ Simples
   ❌ Menos features que concorrentes
   ...

💬 RECOMENDAÇÃO
Pipedrive se quer simplicidade. HubSpot se quer ecossistema completo.
Testar os dois (free trial) antes de decidir.
```

**Variações:**
- "Compara com o que usamos hoje" → lado a lado
- "Pesquisa só opções brasileiras" → filtra
- "Qual o custo de migrar?" → inclui esforço de mudança

---

### 38. Pesquisa rápida sobre uma pessoa antes de uma ligação

**Situação:** Alguém vai te ligar em 10 minutos. Você não lembra quem é.

**O que mandar:**
```
Quem é Ana Luiza Ferreira, da empresa Nexus Digital? Me dá um resumo rápido.
```

**O que o assistente faz:** Pesquisa LinkedIn, site da empresa, busca menções em emails e memória.

**Output esperado:**
```
🔍 ANA LUIZA FERREIRA — NEXUS DIGITAL

- CEO da Nexus Digital, agência de performance em SP
- 15 anos de experiência, ex-iProspect
- Nexus: ~25 pessoas, foco em e-commerce
- LinkedIn: 2.800 conexões, publica sobre mídia paga
- Último contato: email há 45 dias pedindo reunião (você não respondeu)

💡 Provavelmente está ligando pra insistir na reunião.
```

**Dica:** Em 30 segundos você sabe quem é e o que esperar da ligação.

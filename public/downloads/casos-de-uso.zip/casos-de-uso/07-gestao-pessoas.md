# CASOS DE USO — GESTÃO DE PESSOAS

> 6 cenários para liderar, desenvolver e acompanhar o time.

---

### 39. Preparar 1:1 com alguém do time

**Situação:** 1:1 mensal com a Maria (RH). Quer chegar preparado.

**O que mandar:**
```
Prepara minha 1:1 com a Maria. O que preciso falar com ela?
```

**O que o assistente faz:** Busca em time.md, pendencias.md, sessoes/ tudo relacionado à Maria.

**Output esperado:**
```
📋 1:1 COM MARIA (RH)

PENDÊNCIAS DELA
- Retorno sobre candidato analista (pedido há 5 dias)
- Proposta de benefícios nova (prazo: semana que vem)

FEEDBACK PENDENTE
- Onboarding do último contratado foi excelente (reconhecer)

TEMAS PRA DISCUTIR
- Status da vaga de gerente comercial (5 currículos recebidos)
- Rotatividade: 2 saídas no mês. Entender o padrão.
- Budget de treinamento Q3: aprovado ou precisa ajustar?

PERGUNTAS PRA FAZER
- Como você está? (check-in pessoal)
- Tá dando conta do volume ou precisa de reforço?
- Tem algo que eu deveria saber sobre o time?
```

**Variações:**
- "1:1 com o Thamer (comercial)" → foco em números e pipeline
- "1:1 com o Alexandre (financeiro)" → foco em caixa e projeções
- "Histórico de 1:1s com a Maria" → lista anteriores

**Dica:** Após a 1:1, mande o resumo. O assistente guarda e na próxima 1:1 puxa o histórico.

---

### 40. Avaliar desempenho do time no mês

**Situação:** Final do mês. Quer uma visão de como cada pessoa está.

**O que mandar:**
```
Me dá um panorama do time esse mês. Quem entregou, quem não entregou,
o que me preocupa.
```

**O que o assistente faz:** Cruza pendencias.md, decisoes.md, sessoes/ e time.md.

**Output esperado:**
```
📊 PANORAMA DO TIME — ABRIL/2026

✅ DESTAQUES POSITIVOS
- Thamer: bateu meta comercial (112%), fechou 3 clientes enterprise
- Maria: onboarding do novo dev em tempo recorde

⚠️ ATENÇÃO
- Lucas: 3 entregas atrasadas, cliente reclamou (feedback dado dia 10)
- Alexandre: DRE atrasado 5 dias, segunda vez consecutiva

❓ SEM VISIBILIDADE
- Bia: pouquíssimas menções no mês. Tá entregando? Perguntar.

📈 NÚMEROS
- 4 contratações no mês (2 dev, 1 comercial, 1 CS)
- 2 saídas (1 voluntária, 1 demissão)
- NPS interno: não medido esse mês

💡 SUGESTÃO
- Reconhecer Thamer publicamente
- Check-in individual com Bia
- Definir consequência se Alexandre atrasar de novo
```

**Variações:**
- "Panorama do time por área" → agrupa por departamento
- "Quem merece aumento?" → análise baseada em entregas
- "Quem está em risco de sair?" → sinais de desmotivação

**Dica:** Peça panorama mensal e o assistente começa a identificar tendências.

---

### 41. Montar descrição de vaga

**Situação:** Precisa contratar gerente comercial. Quer vaga que atraia gente boa.

**O que mandar:**
```
Monta descrição de vaga pra gerente comercial. B2B SaaS,
time de 8 vendedores, meta agressiva. Precisa ser alguém
que já passou por escala.
```

**O que o assistente faz:** Consulta empresa.md, time.md e objetivos.md pra contexto.

**Output esperado:** Descrição completa com: sobre a empresa (sem clichês), o desafio real da vaga, responsabilidades, requisitos obrigatórios e desejáveis, o que oferece, e como se candidatar. Tom: direto, honesto, atraente.

**Variações:**
- "Vaga mais júnior" → ajusta senioridade
- "Vaga pra LinkedIn" → formato de post
- "Perguntas de entrevista pra essa vaga" → roteiro de entrevista

**Dica:** Peça "analisa os 5 currículos" depois e o assistente filtra baseado na vaga que criou.

---

### 42. Delegar tarefa com clareza

**Situação:** Quer delegar algo mas sabe que se não for claro, vai voltar errado.

**O que mandar:**
```
Me ajuda a delegar pro Alexandre: preciso que ele monte projeção
de caixa dos próximos 6 meses considerando as 3 contratações novas.
Prazo: sexta.
```

**O que o assistente faz:** Estrutura a delegação com contexto, entregável, prazo e critério de sucesso.

**Output esperado:**
```
💬 MENSAGEM DE DELEGAÇÃO

Alexandre, preciso de uma coisa pra sexta:

O QUE PRECISO
Projeção de caixa dos próximos 6 meses (mai-out/2026)

CONTEXTO
Estamos contratando 3 vendedores (R$6k cada + encargos).
Preciso entender o impacto no caixa antes de confirmar.

INCLUIR
- Cenário com 3 contratações
- Cenário com 2 contratações
- Ponto de breakeven de cada cenário
- Premissa de receita incremental (meta R$50k/vendedor após ramp)

FORMATO
Planilha com resumo de 1 página. Não precisa de apresentação.

PRAZO
Sexta 18h. Se precisar de algum dado, me pede até quarta.

---
Quer que eu envie pro Alexandre ou prefere ajustar?
```

**Variações:**
- "Delega pro time inteiro" → distribui tarefas
- "Cria checklist pro estagiário" → passo a passo detalhado
- "Delega com autonomia" → menos controle, mais confiança

**Dica:** O assistente cria pendência automática pro Alexandre com prazo de sexta.

---

### 43. Resolver conflito entre duas pessoas do time

**Situação:** Dois membros do time estão em conflito. Precisa mediar.

**O que mandar:**
```
Thamer e Lucas estão em conflito sobre quem é responsável pelo
cliente Y. Me ajuda a pensar como resolver.
```

**O que o assistente faz:** Busca contexto em time.md e sessoes/, analisa a situação.

**Output esperado:**
```
🤝 MEDIAÇÃO — THAMER × LUCAS

CONTEXTO
Cliente Y: ticket R$4.5k. Thamer fechou a venda. Lucas faz
o atendimento pós-venda. Conflito: cliente pediu mudança no
escopo e Thamer prometeu sem consultar Lucas.

RAIZ DO CONFLITO
Falta de processo claro sobre quem decide mudanças de escopo
após a venda. Não é culpa de nenhum dos dois.

OPÇÕES
1. DEFINIR REGRA: "Mudança de escopo passa pelo CS antes de prometer"
   ✅ Resolve de vez | ❌ Thamer pode achar burocrático

2. DIVIDIR RESPONSABILIDADE: "Comercial vende, CS entrega, mudança é decisão conjunta"
   ✅ Ambos se sentem donos | ❌ Pode gerar impasse

3. ESCALAR PRA VOCÊ: "Mudança de escopo acima de X% passa por mim"
   ✅ Controle | ❌ Gargalo em você

💬 RECOMENDAÇÃO
Opção 1. Conversar com os dois juntos, não separado. Tom:
"Isso aconteceu por falta de processo, não por culpa de ninguém.
Vamos definir a regra agora."
```

**Dica:** Registre a decisão com /decisao e na próxima situação similar o assistente lembra a regra.

---

### 44. Reconhecer publicamente alguém do time

**Situação:** Thamer bateu a meta. Quer reconhecer no grupo.

**O que mandar:**
```
Manda mensagem de reconhecimento pro Thamer no grupo do time.
Bateu 112% da meta. Quero que o time veja.
```

**O que o assistente faz:** Consulta contexto sobre o Thamer e monta mensagem genuína.

**Output esperado:**
```
📢 MENSAGEM PRO GRUPO

Time, quero dar destaque pro resultado do Thamer esse mês.

Meta: R$120k
Entregue: R$134.4k (112%)
3 clientes enterprise fechados

Isso não é só número — cada um desses clientes foi uma
negociação longa, com objeções reais que ele soube conduzir.

Thamer, parabéns. O time todo ganha quando alguém eleva o padrão.
```

**Variações:**
- "Reconhecimento individual (privado)" → mensagem só pra pessoa
- "Reconhecimento do time todo" → resultado coletivo
- "Comemoração: sugere como celebrar" → ideias de celebração

**Dica:** Reconhecimento público + feedback construtivo privado = fórmula de ouro.
